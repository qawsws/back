window.onload = function (){
    const tabContents = document.querySelectorAll("#tabContainer div")
    const tabContents2 = document.querySelectorAll(".tabBtn li");
    for (let i = 0; i<tabContents2.length; i++){
        tabContents2[i].onclick = function () {
            for (let j = 0; j < tabContents2.length; j++){
                tabContents2[j].classList.remove("on");
                tabContents[j].classList.remove("on");
    }
    tabContents2[i].classList.add("on");
    tabContents[i].classList.add("on");
    }
    }
};