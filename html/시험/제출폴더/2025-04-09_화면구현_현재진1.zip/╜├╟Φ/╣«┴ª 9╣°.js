document.addEventListener("DOMContentLoaded", function (){
    const main = document.getElementById("mainImg");
    const bottoms = document.querySelectorAll(".sImg div")
    bottoms.forEach(bottom => {
        bottom.addEventListener("click", () => {
            const imgus = bottom.getAttribute("data-src");
            main.setAttribute("src", imgus);
            bottoms.forEach(t => t.style.border = "none");
            bottom.style.border = "5px solid red";
        });
    });
});